package com.katcom.androidFileVault.DataBase;

public class VaultDbSchema {
    public static final class FileTable{
        public static final String NAME = "files";
    }
}
