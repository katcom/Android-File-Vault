package com.katcom.androidFileVault;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

public class SecureFileViewer implements SecureFileOpener  {
    @Override
    public void openFile(String filename) {
        // TODO
    }

    @Override
    public void openPdf(String filename) {
        // TODO
    }

    @Override
    public void openDocx(String filename) {

    }

    @Override
    public void openTxt(String filename) {

    }

    @Override
    public void openVideo(String filename) {

    }

    @Override
    public void openAudio(String filename) {

    }

    @Override
    public void openPicture(String filename) {

    }

}
